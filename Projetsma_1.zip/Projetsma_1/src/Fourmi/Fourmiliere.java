package Fourmi;

public class Fourmiliere {
    private Position position;

    public Fourmiliere(Position position) {
        this.position = position;
    }

    public Position getPosition() {
        return position;
    }
}


